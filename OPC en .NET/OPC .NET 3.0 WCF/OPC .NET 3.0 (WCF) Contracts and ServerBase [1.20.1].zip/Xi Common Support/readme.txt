This readme file describes the changes to the files in Xi Common Support.

Extensions/ContractDataExt.cs
Address null reference exception in MakeMessageKey()
