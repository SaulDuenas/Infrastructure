﻿namespace LiftBoxApp.Datasets {
    
    
    public partial class LiftBoxDS {
    }
}

