using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Diagnostics;

/***************************************************************************
 *       Clase: TSR-LOG.                                                   *
 * Descripci�n: Permite establecer las funciones b�sicas para el manejo de *
 *              archivos Logs.                                             *
 *      Autor: Ing. Israel Hinojosa S�nchez.                                                   *
 *       Fecha: 17/Sep/2007.                                               *
 *     Versi�n: 1.0.0                                                      *
 ***************************************************************************/

namespace PrintRpt
{
   public enum Nivel
   {
      ERR=0,
      WRN=1,
      INF=2,
      DBG=3
   }
   public class TSR_LOG
   {
      //Constantes.
      //--P�blicas.
      public const int LOG_ERR = 0;  //Log de tipo: Error.
      public const int LOG_WRN = 1;  //Log de tipo: Advertencia.
      public const int LOG_INF = 2;  //Log de tipo: Informativo.
      public const int LOG_DBG = 3;  //Log de Tipo: Depuraci�n.
      public Nivel nDetLog = Nivel.INF; //Nivel de detalle del Log (Default INF).
      //Propiedades.
      //--Privadas.
      private string sArchivo = ""; //Ruta y Nombre del Archivo.
      private string sFecha = "";  //Fecha Actual del Log.
      private string sFileName = ""; //Sol� nombre del archivo.
      private string sPathFile = "";   //Ruta del archivo.
      private bool bExiste;  //Existe el Archivo.
      private bool bUsarEventViewer; //Escribir en el Event Viewer de Windows (True = S�, False = No)
      private string sEvtAppName; //Llave en el Event Viewer.
      private string sEvtFolderName; //Nombre en el Event Viewer.
      private bool bHabilitaDBG; //Llave que habilita la escritura de mensajes debug en el EventViewer.
      private string[] sValoresLog = { "ERR", "WRN", "INF", "DBG" }; //Valores que toma el mensaje a reportar.
      //M�todos.
      //--Publicos.
      //----------------------------------------------------------------------------
      //    Nombre: Constructor (Sin par�metros).
      //  Objetivo: Inicializar la clase, estableciendo el archivo Log con el nombre
      //            de la aplicaci�n que lo manda a llamar, fecha y hora actual.
      //    Autor: Ing. Israel Hinojosa S�nchez.
      //     Fecha: 17/Sep/2007.
      //----------------------------------------------------------------------------
      /// <summary>
      /// Permite registrar mensajes en un archivo Log �nicamente
      /// </summary>
      public TSR_LOG()
      {
         System.Reflection.Assembly InfoFile;  //Informaci�n de la aplicaci�n.

         //[1]Obtener Informaci�n del Ejecutable.
         InfoFile = System.Reflection.Assembly.GetExecutingAssembly();

         //[2]Establecer Nombre del Archivo.
         SetLogFile(Path.GetDirectoryName(InfoFile.Location), Path.GetFileNameWithoutExtension(InfoFile.Location));

         //[3]Desctivar uso de Event Viewer.
         bUsarEventViewer = false;
         sEvtAppName = "";
         sEvtFolderName = "";
      }

      //----------------------------------------------------------------------------
      //    Nombre: Constructor (Con par�metros).
      //  Objetivo: Inicializar la clase, estableciendo el archivo Log con el nombre
      //            de la aplicaci�n que lo manda a llamar, fecha y hora actual.
      //Par�metros:
      //            -Entrada-
      //                pbEventView: Habilita el uso del Event Viewer.
      //                psKeyEventView: Llave unica del Event Viewer.
      //                psNomKeyEventView: Nombre con la que se mostrara el registro
      //                                   en windows.
      //    Autor: Ing. Israel Hinojosa S�nchez.
      //     Fecha: 17/Dic/2008.
      //----------------------------------------------------------------------------
      /// <summary>
      /// Permite registrar mensajes en un archivo Log y adicionalmente en el registro
      /// de eventos del sistema (EventViewer)
      /// </summary>
      /// <param name="pbHabilitaDBG">Indica si debe registrar enventos tipo debug en el EventViewer (Se recomienda false)</param>
      /// <param name="psEvtAppName">Nombre de la aplicaci�n como se registrar� en el EventViewer</param>
      /// <param name="psEvtFolderName">Nombre del Folder dentro del EventViewer. 
      /// Puede ser: Application, System o cualquier otro nombre
      /// </param>
      public TSR_LOG(bool pbHabilitaDBG, string psEvtAppName, string psEvtFolderName)
       {
           System.Reflection.Assembly InfoFile;  //Informaci�n de la aplicaci�n.

           //[1]Obtener Informaci�n del Archivo.
           InfoFile = System.Reflection.Assembly.GetExecutingAssembly();

           //[2]Establecer Nombre del Archivo.
           SetLogFile(Path.GetDirectoryName(InfoFile.Location), Path.GetFileNameWithoutExtension(InfoFile.Location));

           //[3]Inicializar propiedades del Event Viewer.
           bUsarEventViewer = true;
           bHabilitaDBG = pbHabilitaDBG;
           sEvtAppName = psEvtAppName;
           sEvtFolderName = psEvtFolderName;
       }


      //----------------------------------------------------------------------------
      //    Nombre: SetLogFile.
      //  Objetivo: Establece el nombre del archivo Log con fecha actual.
      // Par�mtros: 
      //            -Entrada-
      //               psPathFile: Ruta del Archivo.
      //               psFileName: Nombre del Archivo Log.
      //    Autor: Ing. Israel Hinojosa S�nchez.
      //     Fecha: 17/Sep/2007.
      //----------------------------------------------------------------------------
      public void SetLogFile(string psPathFile, string psFileName)
      {
         DateTime ldFecha = DateTime.Today;
         string lsFecha = "";  //Fecha en Texto.

         //[1]Establecer Fecha y recordar valores.
         sFecha = lsFecha = ldFecha.ToString("yyMMdd");
         sPathFile = psPathFile;
         sFileName = psFileName;

         //[2]Verificar existencia del directorio Logs, s� no existe crearlo.
         if (Directory.Exists(psPathFile + "\\Logs") == false)
            Directory.CreateDirectory(psPathFile + "\\Logs");

         //[3]Establecer nombre del Archivo.
         sArchivo = psPathFile + "\\Logs\\" + psFileName + "_" + lsFecha + ".log";

         //[4]Especificar Existencia del Archivo.
         bExiste = File.Exists(sArchivo);
      }

      //----------------------------------------------------------------------------
      //    Nombre: Reporta.
      //  Objetivo: Establece el mensaje especifico en el archivo Log.
      // Par�mtros: 
      //            -Entrada-
      //               psCodigo: C�digo de Error.
      //              psMensaje: Mensaje de Error.
      //    Autor: Ing. Israel Hinojosa S�nchez.
      //     Fecha: 17/Sep/2007.
      //----------------------------------------------------------------------------
      public void Reporta(Nivel pNivel, string psCode, string psMensaje)
      {
         string lsMensaje = "";  //Mensaje a escribir en el archivo Log.
         Stream lStream;
         StreamWriter loLogFile = null;   //Objeto de control del Archivo Log. (Nuevo)

         if (pNivel <= nDetLog)  //Valida el nivel de detalle a reportar.
         {
            //[1]Inicializa objetos de validaci�n 
            if (bUsarEventViewer)
            {
                if (!EventLog.SourceExists(sEvtAppName))
                    EventLog.CreateEventSource(sEvtAppName, sEvtFolderName);
            }

            //[2]Valida Archivo.
            if (sArchivo == "")
            {
               //Reportar error en el event viewer.
               if (bUsarEventViewer)
                   EventLog.WriteEntry(sEvtAppName, "El archivo LOG no existe.", EventLogEntryType.Error);
            }
            else
            {
               try
               {
                  //[3]Armar mensaje.
                  lsMensaje = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + "\t" + sValoresLog[(int)pNivel] + "\t" + psCode.Trim() + "\t" + psMensaje.Trim();

                  //[A.1]Establecer Archivo Log Nuevo.
                  if (sFecha != DateTime.Today.ToString("yyMMdd")) SetLogFile(sPathFile, sFileName);
                  lStream=File.Open(sArchivo,FileMode.Append,FileAccess.Write,FileShare.ReadWrite);
                  loLogFile = new StreamWriter(lStream);

                  //[A.2]Esteblecer mensaje en el archivo.
                  loLogFile.WriteLine(lsMensaje);

                  //[A.3]Cerrar Archivo.
                  loLogFile.Flush();
                  lStream.Flush();
                  loLogFile.Close();
                  lStream.Close();

                  //[A.4]Actualizar existencia de archivo.
                  bExiste = true;

                  //[A.5]Reportar en el EventViewer.
                  switch (pNivel)
                  {
                      case Nivel.ERR:  //Tipo Error.
                          EventLog.WriteEntry(sEvtAppName, psMensaje, EventLogEntryType.Error);
                          break;
                     case Nivel.WRN:
                          EventLog.WriteEntry(sEvtAppName, psMensaje, EventLogEntryType.Warning);
                          break;
                      case Nivel.INF:  //Tipo Informativo.
                          EventLog.WriteEntry(sEvtAppName, psMensaje, EventLogEntryType.Information);
                          break;
                      case Nivel.DBG:  //Tipo Debug.
                          if (bHabilitaDBG)
                             EventLog.WriteEntry(sEvtAppName, psMensaje, EventLogEntryType.SuccessAudit);
                          break;
                  }

               }
               catch (Exception loErr)
               {
                  //Reportar error en el event viewer.
                  if (bUsarEventViewer)
                      EventLog.WriteEntry(sEvtAppName, "Error en el archivo Log: " + loErr.Message + "    Mensaje original:" + lsMensaje, EventLogEntryType.Error);
                  if (loLogFile!=null) loLogFile.Close();
               }
            }
         }
      }
   }
}
